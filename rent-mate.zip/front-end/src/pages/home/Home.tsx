import React from 'react';

const Home: React.FC = () => {
  return (
    <div>
      <h1>Welcome to RentMate</h1>
      <p>Your one-stop solution for finding and managing rental Apartments.</p>
    </div>
  );
};

export default Home;
